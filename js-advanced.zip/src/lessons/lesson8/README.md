Занятие 8 (Iterator, Generator, Redux-Thunk, Redux-Saga):

Изучить ссылки в файле lesson8.ts

1) изучить ссылки
2) решить задачи